import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import BigNumber from "bignumber.js";
import PropTypes from "prop-types";
import styles from "./transfer-footer.module.css";
import { selectExchange, selectRate } from "../currency/store/currency-slice";
import NumberService from "../../app/services/number-service";

// @ts-ignore
export default function TransferFooter({ from, to, amount }) {
  const exchange = useSelector((state) => selectExchange(state, from, to));
  const hasSummary = from !== undefined && to !== undefined && amount !== undefined;
  const rate = useSelector((state) => selectRate(state, from, to));
  const [transferSummary, setTransferSummary] = useState("");

  useEffect(() => {
    // Format some code here
    if (hasSummary) {
      setTransferSummary(`Transfer ${amount} ${from} to ${to} ${rate ? `at rate ${rate}` : ''}`);
    } else {
      setTransferSummary("");
    }


  }, [amount, from, to, exchange, rate]);

  return <div className={styles.footer__panel}>{transferSummary}</div>;
}

TransferFooter.defaultProps = {
  from: undefined,
  to: undefined,
  amount: undefined,
};

TransferFooter.propTypes = {
  from: PropTypes.string,
  to: PropTypes.string,
  amount: PropTypes.number,
};
