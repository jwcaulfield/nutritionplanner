import React from "react";
import {
  Accordion,
  AccordionSummary,
  Typography,
  AccordionDetails,
  List,
  ListItem,
  makeStyles,
} from "@material-ui/core";
import { useSelector } from "react-redux";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { selectFavourites } from "./store/favourite-slice";
import styles from "./favourites.module.css";
import FavouriteItem from "./favourite-item";
import AddFavourite from "./favourite-add";

const useStyles = makeStyles({
  panelRoot: {
    overflow: "hidden",
  },
  listRoot: {
    "min-width": "300px",
  },
});

export default function Favourites() {
  const classes = useStyles();
  const favourites = useSelector(selectFavourites);
  const hasFavourites = favourites && favourites.length > 0;

  return (
    <div>
      <Accordion classes={{ root: classes.panelRoot }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <div className={styles.title}>
            <Typography
              align="left"
              variant="subtitle1"
              className={styles.title__text}
            >
              My Favourites
            </Typography>
          </div>
          <div className={styles.title__description}>
            <Typography align="left" variant="subtitle2">
              Click here to add a new favourite...
            </Typography>
          </div>
        </AccordionSummary>
        <AccordionDetails>
          <AddFavourite />
        </AccordionDetails>
      </Accordion>
      {hasFavourites && (
        <List classes={{ root: classes.listRoot }}>
          {favourites?.map((favourite) => (
            <ListItem
              key={`${favourite.from}:${favourite.to}`}
              className={styles.favourite__panel}
            >
              <FavouriteItem from={favourite.from} to={favourite.to} />
            </ListItem>
          ))}
        </List>
      )}
    </div>
  );
}
