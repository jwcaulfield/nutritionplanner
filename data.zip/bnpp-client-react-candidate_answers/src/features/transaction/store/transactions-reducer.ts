import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';
import { Transaction } from '../models/transaction';

const initialState: Transaction[] = [];

export const transactionReducerName = 'transactions';

export default function reducer(
  state = initialState,
  action: PayloadAction<Transaction[]>
): Transaction[] {
  if (action.type === 'load-transactions') {
    return action.payload; // Return the Data Here
  }

  return state;
}

storeInitialState[transactionReducerName] = initialState;

storeRegistry.addReducer(transactionReducerName, reducer);
