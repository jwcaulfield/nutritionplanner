import {
  Accordion,
  AccordionSummary,
  Button,
  IconButton,
  List,
  ListItem,
  makeStyles,
  Typography,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { v4 as uuid } from "uuid";
import SyncIcon from "@material-ui/icons/Sync";
import styles from "./transactions.module.css";
import {
  loadTransactions,
  selectTransactions,
} from "./store/transactions-slice";
import TransactionItem from "./transaction-item";
import { selectTransferId } from "../transfer/store/transfer-slice";

const useStyles = makeStyles({
  listRoot: {
    display: "block",
  },
  buttonRoot: {
    float: "right",
    margin: "0 10px 10px 0",
  },
  accordionRoot: {
    "margin-top": "10px",
  },
});

export default function Transactions() {
  const dispatch = useDispatch();
  const transactions = useSelector(selectTransactions);
  const hasTransactions = transactions && transactions.length > 0;
  const [highlight, setHighlight] = useState(false);
  const transferId = useSelector(selectTransferId);
  const classes = useStyles();

  useEffect(() => {
    loadTransactions(dispatch).then(() => {
      if (transferId && transferId.length > 0) {
        setHighlight(true);

        setTimeout(() => {
          setHighlight(false);
        }, 5000);
      }
    });
  }, [dispatch, transferId]);

  const isHighlighted = (index: number) => index === 0 && highlight;

  return (
    <Accordion classes={{ root: classes.accordionRoot }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
        <div className={styles.title}>
          <Typography
            align="left"
            variant="subtitle1"
            className={styles.title__text}
          >
            My Transactions
          </Typography>
        </div>
        <div className={styles.title__description}>
          <Typography align="left" variant="subtitle2">
            Lists all your account transfers
          </Typography>
          <IconButton
            edge="end"
            size="small"
            aria-label="refresh"
            onClick={() => loadTransactions(dispatch).then()}
          >
            <SyncIcon />
          </IconButton>
        </div>
      </AccordionSummary>
      <div>
      {hasTransactions && (
        <List classes={{ root: classes.listRoot }}>
          {transactions?.map((transaction, index) => (
            <ListItem
              key={`${transaction.timestamp}`}
            >
              <TransactionItem highlighted={isHighlighted(index)} transaction={transaction} />
            </ListItem>
          ))}
        </List>
      )}
      </div>
    </Accordion>
  );
}
