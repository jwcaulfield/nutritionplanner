import React, { useState } from "react";
import PropTypes from "prop-types";
import ReorderIcon from "@material-ui/icons/Reorder";
import { Button, makeStyles, Switch } from "@material-ui/core";
import { useDispatch, useSelector } from "react-redux";
import NumberService from "../../app/services/number-service";
import styles from "./wallet-account.module.css";
import { rechargeAccount, selectAccount } from "./store/wallet-slice";
import ExchangeAmount from "../exchange/exchange-amount";

const useStyles = makeStyles({
  buttonRoot: {
    width: "140px",
    "margin-top": "5px",
  },
});

// @ts-ignore
export default function WalletAccount({ code }) {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [enabled, setEnabled] = useState(true);
  const [amount, setAmount] = useState<number | undefined>(undefined);
  const account = useSelector((state) => selectAccount(state, code));
  const canRecharge = enabled && account && amount != null && amount > 0;

  const handleEnabled = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEnabled(event.target.checked);
  };

  const handleRecharge = async () => {
    await rechargeAccount(
      code,
      amount ?? 0,
      dispatch
    )
  };

  const balance = account?.value ? NumberService.formatAmount(account.value) : "unknown";

  return (
    <div className={styles.container}>
      <div className={styles.header__panel}>
        <ReorderIcon color="primary" />
        <span className={styles.header__title}>{`Account for ${code}, Balance ${balance}`}</span>
        <Switch
          checked={enabled}
          onChange={handleEnabled}
          inputProps={{ "aria-label": "primary checkbox" }}
        />
      </div>
      <div>
        <ExchangeAmount
          label="Recharge Amount"
          amount={amount}
          amountChanged={(value) => {
            setAmount(value);
          }}
        />
        <Button
          variant="contained"
          color="primary"
          size="small"
          disabled={!canRecharge}
          classes={{ root: classes.buttonRoot }}
          onClick={handleRecharge}
        >
          Recharge
        </Button>
      </div>
    </div>
  );
}

WalletAccount.propTypes = {
  code: PropTypes.string.isRequired,
};
