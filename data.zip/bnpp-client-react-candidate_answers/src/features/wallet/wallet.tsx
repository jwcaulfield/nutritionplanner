import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  makeStyles,
  Typography,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import React, { MouseEvent, useCallback, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  DragDropContext,
  Draggable,
  Droppable,
  DropResult,
} from "react-beautiful-dnd";
import styles from "./wallet.module.css";
import { loadAccounts, selectAccounts } from "./store/wallet-slice";
import WalletAccount from "./wallet-account";
import { selectTransferId } from "../transfer/store/transfer-slice";

const useStyles = makeStyles(() => ({
  accordionRoot: {
    "margin-top": "10px",
  },
  accordionDetailsRoot: {
    "flex-direction": "column",
  },
}));

export default function Wallet() {
  const classes = useStyles();
  const dispatch = useDispatch();
  const accounts = useSelector(selectAccounts);
  const [accountCodes, setAccountCodes] = useState<string[]>([]);
  const transferId = useSelector(selectTransferId);
  const hasAccounts = accounts && accounts.length > 0;
  const hasAccountCodes = useRef(false);

  useEffect(() => {
    loadAccounts(dispatch).then();

    if (hasAccounts && !hasAccountCodes.current) {
      setAccountCodes(accounts!.map((account) => account.code));

      hasAccountCodes.current = true;
    }
  // eslint-disable-next-line
  }, [transferId, hasAccounts]);

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) {
      return;
    }

    const newAccountCodes = accountCodes.slice(0);

    const [removed] = newAccountCodes.splice(result.source.index, 1);

    newAccountCodes.splice(result.destination.index, 0, removed);

    setAccountCodes(newAccountCodes);
  };

  const sortWallet = useCallback((e: MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    console.log('Sorting Wallet');

    accountCodes.sort((a, b) => a.localeCompare(b));
    setAccountCodes([...accountCodes]);
  }, [accountCodes]);

  return (
    <div>
      <Accordion classes={{ root: classes.accordionRoot }}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <div className={styles.title}>
            <Typography
              align="left"
              variant="subtitle1"
              className={styles.title__text}
            >
              My Wallet
            </Typography>
          </div>
          <div className={styles.title__description}>
            <Typography align="left" variant="subtitle2">
              Lists all your active currency accounts
            </Typography>
          </div>
          <div>
            <Button onClick={sortWallet} className={styles.sortButton}>Sort Wallet</Button>
          </div>
        </AccordionSummary>
        <AccordionDetails classes={{ root: classes.accordionDetailsRoot }}>
          {hasAccounts && (
            <DragDropContext onDragEnd={(result) => onDragEnd(result)}>
              <Droppable droppableId="wallet-droppable">
                {(provided) => (
                  <div ref={provided.innerRef}>
                    {accountCodes.map((accountCode, index) => (
                      <Draggable
                        key={accountCode}
                        draggableId={accountCode}
                        index={index}
                      >
                        {(draggableProvided) => (
                          <div
                            ref={draggableProvided.innerRef}
                            // eslint-disable-next-line react/jsx-props-no-spreading
                            {...draggableProvided.draggableProps}
                            // eslint-disable-next-line react/jsx-props-no-spreading
                            {...draggableProvided.dragHandleProps}
                          >
                            <WalletAccount code={accountCode} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          )}
          {!hasAccounts && (
            <div className={styles.no__accounts}>
              No accounts are available. Please check the server is available
            </div>
          )}
        </AccordionDetails>
      </Accordion>
    </div>
  );
}
