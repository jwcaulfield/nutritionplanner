import BigNumber from 'bignumber.js';

export default class NumberService {
  public static formatAmount(value?: number): string {
    if (value == null || Number.isNaN(value)) {
      return '';
    }

    return new BigNumber(value).toFormat(2);
  }

  public static formatRate(value?: number): string {
    if (value == null || Number.isNaN(value)) {
      return '';
    }

    return new BigNumber(value).toFormat(5);
  }

  public static parseAmount(value?: string): number {
    if (value == null) {
      return 0;
    }

    const valueAsNumber = new BigNumber(value);

    if (valueAsNumber.isNaN() || valueAsNumber.isNegative()) {
      return 0;
    }

    return valueAsNumber.toNumber();
  }

  public static parseAmountNullable(value?: string): number | undefined {
    if (NumberService.isEmpty(value)) {
      return undefined;
    }

    return NumberService.parseAmount(value);
  }

  public static isEmpty(value?: string): boolean {
    if (value == null || value.trim().length === 0) {
      return true;
    }

    return false;
  }

  public static isNegative(value?: string): boolean {
    return new BigNumber(value ?? 0).isNegative();
  }
}
