export default class HttpService {
  public static formatUri(endpoint: string): string {
    return `http://localhost:3000/${endpoint}`;
  }
}
