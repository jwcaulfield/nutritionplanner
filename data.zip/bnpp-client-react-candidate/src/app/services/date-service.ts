import { format } from 'date-fns';

export default class DateService {
  public static formatDateTime(value: Date): string {
    if (value == null) {
      return '';
    }

    return format(value, 'dd/MM/yyyy HH:mm:ss');
  }
}
