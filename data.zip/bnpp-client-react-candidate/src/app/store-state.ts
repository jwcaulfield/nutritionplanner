import Favourite from '../features/favourite/models/favourite';
import { Transaction } from '../features/transaction/models/transaction';
import { CurrencyExchange } from '../features/currency/models/currency-exchange';
import { Account } from '../features/wallet/models/account';

export default interface StoreState {
  favourites?: Favourite[];
  currencyCodes?: string[];
  currencyExchanges?: CurrencyExchange[];
  currencyRates?: Map<string, number>;
  transactions?: Transaction[];
  accounts?: Account[];
  transferId?: string;
}
