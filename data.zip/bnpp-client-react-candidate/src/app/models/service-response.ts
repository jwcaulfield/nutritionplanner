export default interface ServiceResponse {
    success: boolean;
    successMessage?: string;
    errorMessage?: string;
}
