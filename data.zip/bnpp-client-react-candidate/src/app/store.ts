import {
  ThunkAction,
  Action,
  combineReducers,
  createStore,
  applyMiddleware,
} from '@reduxjs/toolkit';
import thunk from 'redux-thunk';
import storeRegistry from './store-registry';
import storeInitialState from './store-initial';

const combine = (reducers: { [x: string]: (state?: null) => null }) => {
  const reducerNames = Object.keys(reducers);
  Object.keys(storeInitialState).forEach((item) => {
    if (reducerNames.indexOf(item) === -1) {
      // eslint-disable-next-line no-param-reassign
      reducers[item] = (state = null) => state;
    }
  });
  return combineReducers(reducers);
};

const reducer = combine(storeRegistry.getReducers());
const store = createStore(reducer, applyMiddleware(thunk));

// Replace the store's reducer whenever a new reducer is registered.
storeRegistry.setListener((reducers) => {
  store.replaceReducer(combine(reducers));
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
