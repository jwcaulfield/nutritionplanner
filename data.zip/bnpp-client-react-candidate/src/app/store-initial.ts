import StoreState from './store-state';

const storeInitialState: StoreState = {
  currencyCodes: [],
  currencyExchanges: [],
  currencyRates: new Map<string, number>(),
  favourites: [],
  transactions: [],
  accounts: [],
};

export default storeInitialState;
