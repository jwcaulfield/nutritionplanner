export class StoreRegistry {
  private _reducers = {};
  private _onChange: ((reducers: any) => void) | undefined;

  public getReducers(): any {
    return { ...this._reducers };
  }

  public addReducer(name: string, reducer: any): void {
    this._reducers = { ...this._reducers, [name]: reducer };

    if (this._onChange) {
      this._onChange(this.getReducers());
    }
  }

  public setListener(listener: (reducers: any) => void): void {
    this._onChange = listener;
  }
}

const storeRegistry = new StoreRegistry();

export default storeRegistry;
