import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import {
  FormControl,
  InputLabel,
  makeStyles,
  MenuItem,
  Select,
} from "@material-ui/core";
import { useSelector } from "react-redux";
import { selectCodes } from "../currency/store/currency-slice";

const useStyles = makeStyles(() => ({
  formControl: {
    "padding-right": 20,
    width: 150,
  },
}));

// @ts-ignore
export default function ExchangePicker({ from, fromChanged, to, toChanged }) {
  const classes = useStyles();
  const currencies = useSelector(selectCodes) ?? [];
  const [fromCurrency, setFromCurrency] = useState(from);
  const [toCurrency, setToCurrency] = useState(to);

  const fromCurrencies = currencies.filter((item) => item !== toCurrency);
  const toCurrencies = currencies.filter((item) => item !== fromCurrency);
  const hasFromCurrencies = fromCurrencies.length > 0;
  const hasToCurrencies = toCurrencies.length > 0;

  const handleFromCurrency = (
    event: React.ChangeEvent<{ name?: string; value: unknown }>
  ) => {
    const fromValue = event.target.value;
    setFromCurrency(fromValue);

    if (fromChanged) {
      fromChanged(fromValue);
    }
  };

  const handleToCurrency = (
    event: React.ChangeEvent<{ name?: string; value: unknown }>
  ) => {
    const toValue = event.target.value;
    setToCurrency(toValue);

    if (toChanged) {
      toChanged(toValue);
    }
  };

  useEffect(() => {
    setFromCurrency(from);
    setToCurrency(to);
  }, [from, to]);

  return (
    <>
      <FormControl
        className={classes.formControl}
        disabled={!hasFromCurrencies}
      >
        <InputLabel>From Currency</InputLabel>
        <Select value={fromCurrency} onChange={handleFromCurrency}>
          {fromCurrencies?.map((code: string) => (
            <MenuItem key={code} value={code}>
              {code}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl className={classes.formControl} disabled={!hasToCurrencies}>
        <InputLabel>To Currency</InputLabel>
        <Select value={toCurrency} onChange={handleToCurrency}>
          {toCurrencies?.map((code: string) => (
            <MenuItem key={code} value={code}>
              {code}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </>
  );
}

ExchangePicker.defaultProps = {
  from: undefined,
  fromChanged: undefined,
  to: undefined,
  toChanged: undefined,
};

ExchangePicker.propTypes = {
  from: PropTypes.string,
  fromChanged: PropTypes.func,
  to: PropTypes.string,
  toChanged: PropTypes.func,
};
