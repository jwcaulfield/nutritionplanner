import React, { useState } from "react";
import PropTypes from "prop-types";
import { TextField } from "@material-ui/core";
import NumberService from "../../app/services/number-service";

// @ts-ignore
export default function ExchangeAmount({ label, amount, amountChanged }) {
  const [amountInput, setAmountInput] = useState(amount?.toString() ?? "");

  const setAmount = (valueString: string, value: number | undefined) => {
    setAmountInput(valueString);

    if (amountChanged) {
      amountChanged(value);
    }
  };

  const handleAmount = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    if (NumberService.isEmpty(value) || NumberService.isNegative(value)) {
      setAmount("", undefined);
    } else {
      setAmount(value, NumberService.parseAmountNullable(value));
    }
  };

  return (
    <TextField
      label={label}
      type="number"
      InputLabelProps={{
        shrink: true,
      }}
      value={amountInput}
      onChange={handleAmount}
    />
  );
}

ExchangeAmount.defaultProps = {
  label: "",
  amount: undefined,
  amountChanged: undefined,
};

ExchangeAmount.propTypes = {
  label: PropTypes.string,
  amount: PropTypes.number,
  amountChanged: PropTypes.func,
};
