import Favourite from '../models/favourite';
import ServiceResponse from '../../../app/models/service-response';
import HttpService from '../../../app/services/http-service';

export default class FavouriteService {
  public static exists(item: Favourite, items: Favourite[]): boolean {
    return FavouriteService.find(item, items) > -1;
  }

  public static find(item: Favourite, items: Favourite[]): number {
    if (!item || !items || items.length === 0) {
      return -1;
    }

    return items.findIndex(
      (value) => value.from === item.from && value.to === item.to
    );
  }

  public static async add(from: string, to: string): Promise<ServiceResponse> {
    try {
      console.log(`ADDING currency favourite: 'from' = ${from} / 'to' = ${to}`);

      const url = new URL(HttpService.formatUri('api/Favorite'));
      const params = new URLSearchParams();

      params.append('fromCode', from);
      params.append('toCode', to);

      url.search = params.toString();

      await fetch(url.toString(), {
        method: 'PUT',
      });

      return {
        success: true,
      };
    } catch (error) {
      console.error(
        `FAILED to add favourite '${from}/${to}' to store: '${error}'`
      );

      return {
        success: false,
        errorMessage: `${error}`,
      };
    }
  }

  public static async remove(
    from: string,
    to: string
  ): Promise<ServiceResponse> {
    try {
      console.log(
        `REMOVING currency favourite: 'from' = ${from} / 'to' = ${to}`
      );

      const url = new URL(HttpService.formatUri('api/Favorite'));
      const params = new URLSearchParams();

      params.append('fromCode', from);
      params.append('toCode', to);

      url.search = params.toString();

      await fetch(url.toString(), {
        method: 'DELETE',
      });

      return {
        success: true,
      };
    } catch (error) {
      console.error(
        `FAILED to remove favourite '${from}/${to}' from store: '${error}'`
      );

      return {
        success: false,
        errorMessage: `${error}`,
      };
    }
  }
}
