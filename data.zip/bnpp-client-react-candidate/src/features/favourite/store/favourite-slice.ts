import { reducerName } from './favourite-reducer';
import Favourite from '../models/favourite';
import StoreState from '../../../app/store-state';

// selectors
export const selectFavourites = (state: StoreState) => state[reducerName];

// action creators
export const addFavourite = (payload: Favourite) => ({ payload, type: 'add' });
export const removeFavourite = (payload: Favourite) => ({
  payload,
  type: 'remove',
});
