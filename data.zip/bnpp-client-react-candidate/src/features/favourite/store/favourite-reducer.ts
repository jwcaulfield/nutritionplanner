import { PayloadAction } from '@reduxjs/toolkit';
import storeRegistry from '../../../app/store-registry';
import Favourite from '../models/favourite';
import storeInitialState from '../../../app/store-initial';
import FavouriteService from '../services/favourite-service';

const initialState = [
  new Favourite('EUR', 'USD'),
  new Favourite('EUR', 'GBP'),
  new Favourite('GBP', 'USD'),
];

export const reducerName = 'favourites';

export default function reducer(
  state = initialState,
  action: PayloadAction<Favourite>
): Favourite[] {
  if (action.type === 'add') {
    if (action.payload) {
      FavouriteService.add(action.payload.from, action.payload.to).catch();

      return state?.length
        ? state.concat(...[action.payload])
        : [action.payload];
    }
  } else if (action.type === 'remove') {
    if (action.payload && state) {
      const existing = FavouriteService.find(action.payload, state);
      // @ts-ignore
      if (existing > -1) {
        FavouriteService.remove(action.payload.from, action.payload.to).catch();

        // @ts-ignore
        const items = state.slice(0);
        // @ts-ignore
        items.splice(existing, 1);
        // remove item
        return items;
      }
    }
  }

  return state;
}

storeInitialState[reducerName] = initialState;

storeRegistry.addReducer(reducerName, reducer);
