import { Button } from "@material-ui/core";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import styles from "./favourite-add.module.css";
import { addFavourite, selectFavourites } from "./store/favourite-slice";
import Favourite from "./models/favourite";
import FavouriteService from "./services/favourite-service";
import ExchangePicker from "../exchange/exchange-picker";

export default function AddFavourite() {
  const favourites = useSelector(selectFavourites);
  const dispatch = useDispatch();
  const [fromCurrency, setFromCurrency] = useState("");
  const [toCurrency, setToCurrency] = useState("");

  const handleFromCurrency = (value: string) => {
    setFromCurrency(value);
  };

  const handleToCurrency = (value: string) => {
    setToCurrency(value);
  };

  const disableAddFavourite = () => {
    if (fromCurrency.length === 0 || toCurrency.length === 0) {
      return true;
    }

    return FavouriteService.exists(
      new Favourite(fromCurrency, toCurrency),
      favourites ?? []
    );
  };

  return (
    <div className={styles.add__container}>
      <div className={styles.add__panel}>
        <ExchangePicker
          from={fromCurrency}
          fromChanged={handleFromCurrency}
          to={toCurrency}
          toChanged={handleToCurrency}
        />
      </div>
      <Button
        variant="contained"
        color="primary"
        disabled={disableAddFavourite()}
        onClick={() =>
          dispatch(addFavourite(new Favourite(fromCurrency, toCurrency)))
        }
      >
        Add
      </Button>
    </div>
  );
}
