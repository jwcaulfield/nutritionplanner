import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { IconButton, ListItemSecondaryAction } from "@material-ui/core";
import DeleteIcon from "@material-ui/icons/Delete";
import { useDispatch, useSelector } from "react-redux";
import ArrowDropUpIcon from "@material-ui/icons/ArrowDropUp";
import ArrowDropDownIcon from "@material-ui/icons/ArrowDropDown";
import styles from "./favourite-item.module.css";
import { removeFavourite } from "./store/favourite-slice";
import Favourite from "./models/favourite";
import { selectRate } from "../currency/store/currency-slice";
import NumberService from "../../app/services/number-service";

enum RateDirection {
  Up,
  Down,
  Neutral,
}
// @ts-ignore
export default function FavouriteItem({ from, to }) {
  const rate = useSelector((state) => selectRate(state, from, to));
  const rateAvailable = rate != null;
  const [rateCached, setRateCached] = useState(rate);
  const [rateDirection, setRateDirection] = useState(RateDirection.Neutral);
  const dispatch = useDispatch();

  useEffect(() => {
    let direction = RateDirection.Neutral;
    if (rateCached != null && rate != null) {
      if (rate > rateCached) {
        direction = RateDirection.Up;
      } else if (rate < rateCached) {
        direction = RateDirection.Down;
      }
    }

    setRateCached(rate);
    setRateDirection(direction);
  }, [rate, rateCached]);

  const getRateDirectionStyle = () => {
    switch (rateDirection) {
      case RateDirection.Down:
        return styles.favourite__currency__rate__down;
      case RateDirection.Up:
        return styles.favourite__currency__rate__up;

      default:
        return styles.favourite__currency__rate__neutral;
    }
  };

  return (
    <div>
      <div className={styles.favourite__container}>
        <div
          className={`${styles.favourite__panel__item} ${styles.favourite__panel__item__currency}`}
        >
          <span className={styles.favourite__currency__label}>From</span>
          <span
            className={`${styles.favourite__currency} ${styles.favourite__currency__from}`}
          >
            {from}
          </span>
        </div>
        <div
          className={`${styles.favourite__panel__item} ${styles.favourite__panel__item__currency}`}
        >
          <span className={styles.favourite__currency__label}>To</span>
          <span
            className={`${styles.favourite__currency} ${styles.favourite__currency__to}`}
          >
            {to}
          </span>
        </div>
        <div
          className={`${styles.favourite__panel__item} ${styles.favourite__panel__item__rate}`}
        >
          <span className={styles.favourite__currency__label}>Rate</span>
          {rateAvailable && (
            <div className={styles.favourite__currency__rate__panel}>
              <span
                className={`${
                  styles.favourite__currency__rate
                } ${getRateDirectionStyle()} `}
              >
                {NumberService.formatRate(rate)}
              </span>
              {rateDirection === RateDirection.Up && <ArrowDropUpIcon />}
              {rateDirection === RateDirection.Down && <ArrowDropDownIcon />}
            </div>
          )}
          {!rateAvailable && (
            <span className={styles.favourite__currency__rate__missing}>
              Waiting...
            </span>
          )}
        </div>
      </div>

      <ListItemSecondaryAction>
        <IconButton
          edge="end"
          aria-label="delete"
          onClick={() => dispatch(removeFavourite(new Favourite(from, to)))}
        >
          <DeleteIcon />
        </IconButton>
      </ListItemSecondaryAction>
    </div>
  );
}

FavouriteItem.propTypes = {
  from: PropTypes.string.isRequired,
  to: PropTypes.string.isRequired,
};
