export default class Favourite {
  public constructor(from: string, to: string) {
    if (from === to) {
      throw new Error(
        "Cannot construct a currency transfer favourite where the 'from' currency is equivalent to the 'to' currency"
      );
    }

    this.from = from.toUpperCase();
    this.to = to.toUpperCase();
  }

  public from: string;
  public to: string;
  public currentPrice?: string;
}
