import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';

const initialState: string = '';

export const transferIdReducerName = 'transferId';

export default function reducer(
  state = initialState,
  action: PayloadAction<string>
): string {
  if (action.type === 'load-transfer-id') {
    return action.payload;
  }

  return state;
}

storeInitialState[transferIdReducerName] = initialState;

storeRegistry.addReducer(transferIdReducerName, reducer);
