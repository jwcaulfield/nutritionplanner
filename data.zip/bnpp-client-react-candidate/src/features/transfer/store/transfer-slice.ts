// action creators
import { Dispatch } from 'react';
import TransferService from '../services/transfer-service';
import StoreState from '../../../app/store-state';
import { transferIdReducerName } from './transfer-id-reducer';

export const selectTransferId = (state: StoreState) =>
  state[transferIdReducerName];

export async function transferFunds(
  id: string,
  from: string,
  to: string,
  amount: number,
  dispatch: Dispatch<any>
): Promise<boolean> {
  if (await TransferService.transfer(from, to, amount)) {
    dispatch({ type: 'load-transfer-id', payload: id });

    return true;
  }

  return false;
}
