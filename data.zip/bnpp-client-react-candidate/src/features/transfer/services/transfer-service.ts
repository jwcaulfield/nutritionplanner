import HttpService from '../../../app/services/http-service';

export default class TransferService {
  public static async transfer(
    from: string,
    to: string,
    value: number
  ): Promise<boolean> {
    try {
      console.log(
        `TRANSFERRING funds (${value}): from '${from}' to '${to}' accounts`
      );

      const url = new URL(HttpService.formatUri('api/Trade'));
      const params = new URLSearchParams();

      params.append('value', value?.toString());
      params.append('fromCode', from);
      params.append('toCode', to);

      url.search = params.toString();

      const response = await fetch(url.toString(), {
        method: 'POST',
      });

      const responseBody = await response.json();

      return responseBody.success;
    } catch (error) {
      console.error(`FAILED to transfer currency '${from}/${to}': '${error}'`);

      return false;
    }
  }
}
