import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  IconButton,
  makeStyles,
  Menu,
  MenuItem,
  Switch,
  Typography,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import React, { useState } from "react";
import FavoriteIcon from "@material-ui/icons/Favorite";
import DoubleArrowIcon from "@material-ui/icons/DoubleArrow";
import { useDispatch, useSelector } from "react-redux";
import { v4 as uuid } from "uuid";
import { CancelOutlined } from "@material-ui/icons";
import styles from "./transfer.module.css";
import { selectExchange } from "../currency/store/currency-slice";
import { selectFavourites } from "../favourite/store/favourite-slice";
import Favourite from "../favourite/models/favourite";
import { transferFunds } from "./store/transfer-slice";
import TransferFooter from "./transfer-footer";
import ExchangeAmount from "../exchange/exchange-amount";
import ExchangePicker from "../exchange/exchange-picker";

const useStyles = makeStyles(() => ({
  buttonFavourite: {
    "margin-right": "20px",
  },
  buttonTransfer: {
    "margin-left": "20px",
  },
  accordionDetails: {
    "align-items": "center",
  },
  iconRoot: {
    fill: "white",
  },
}));

export default function Transfer() {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [locked, setLocked] = useState(false);
  const [errored, setError] = useState(false);
  const [fromCurrency, setFromCurrency] = useState("");
  const [toCurrency, setToCurrency] = useState("");
  const [amount, setAmount] = useState<number | undefined>(undefined);
  const favourites = useSelector(selectFavourites);
  const hasFavourites = favourites && favourites.length > 0;
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const canTransfer =
    !locked &&
    fromCurrency?.length > 0 &&
    toCurrency?.length > 0 &&
    amount != null &&
    amount > 0 &&
    fromCurrency !== toCurrency;
  const exchange = useSelector((store) =>
    selectExchange(store, fromCurrency, toCurrency)
  );

  const handleFavouriteMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleFavouriteClose = () => {
    setAnchorEl(null);
  };

  const handleFavouriteSelected = (favourite: Favourite) => {
    setFromCurrency(favourite.from);
    setToCurrency(favourite.to);

    handleFavouriteClose();
  };

  const handleFromCurrency = (value: string) => {
    setFromCurrency(value);
  };

  const handleToCurrency = (value: string) => {
    setToCurrency(value);
  };

  const handleTransfer = async () => {
    if (
      await transferFunds(
        uuid(),
        fromCurrency,
        toCurrency,
        amount ?? 0,
        dispatch
      )
    ) {
      setError(false);
    } else {
      setError(true);
    }
  };

  const handleLocked = (event: React.ChangeEvent<HTMLInputElement>) => {
    setLocked(event.target.checked);
  };

  return (
    <div>
      <Accordion defaultExpanded={false}>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <div className={styles.title}>
            <Typography
              align="left"
              variant="subtitle1"
              className={styles.title__text}
            >
              Transfer Funds
            </Typography>
          </div>
          <div className={styles.title__description}>
            <Typography align="left" variant="subtitle2">
              Allows you to move your money from one account to another
            </Typography>
          </div>
        </AccordionSummary>
        <AccordionDetails classes={{ root: classes.accordionDetails }}>
          <Typography align="left" variant="subtitle2">
            Lock Trading
          </Typography>
          <Switch
            checked={locked}
            onChange={handleLocked}
            inputProps={{ "aria-label": "primary checkbox" }}
          />
        </AccordionDetails>
      </Accordion>
      <div>
        <div className={styles.transfer__panel}>
          <div className={styles.currency__panel}>
            <IconButton
              size="small"
              aria-label="refresh"
              classes={{ root: classes.buttonFavourite }}
              disabled={!hasFavourites}
              onClick={handleFavouriteMenu}
            >
              <FavoriteIcon />
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleFavouriteClose}
            >
              {favourites?.map((favourite: Favourite) => (
                <MenuItem
                  key={`${favourite.from}:${favourite.to}`}
                  onClick={() => handleFavouriteSelected(favourite)}
                >
                  <span>{favourite.from}</span>
                  <DoubleArrowIcon color="primary" />
                  <span>{favourite.to}</span>
                </MenuItem>
              ))}
            </Menu>
            <ExchangePicker
              from={fromCurrency}
              fromChanged={handleFromCurrency}
              to={toCurrency}
              toChanged={handleToCurrency}
            />
            <div className={styles.currency__symbol}>
              {exchange?.fromSymbol}
            </div>
            <ExchangeAmount
              label="Move Funds"
              amount={amount}
              amountChanged={(value) => {
                setAmount(value);
              }}
            />
          </div>
          <Button
            variant="contained"
            color="primary"
            size="small"
            disabled={!canTransfer}
            classes={{ root: classes.buttonTransfer }}
            onClick={handleTransfer}
          >
            Transfer
          </Button>
        </div>
        <TransferFooter from={fromCurrency} to={toCurrency} amount={amount} />
        {errored && (
          <div className={styles.error__panel}>
            <span>
              The transfer of funds failed. Please check to see if you have
              enough money in your wallet account.
            </span>
            <IconButton
              edge="end"
              size="small"
              aria-label="close"
              onClick={() => setError(false)}
            >
              <CancelOutlined
                fontSize="inherit"
                classes={{ root: classes.iconRoot }}
              />
            </IconButton>
          </div>
        )}
      </div>
    </div>
  );
}
