export interface Account {
  code: string;
  value?: number;
}
