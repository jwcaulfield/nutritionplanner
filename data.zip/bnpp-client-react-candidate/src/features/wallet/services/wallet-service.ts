import HttpService from '../../../app/services/http-service';
import { Account } from '../models/account';

export default class WalletService {
  public static async loadAccounts(): Promise<Account[]> {
    try {
      console.log('LOADING wallet accounts');

      const response = await fetch(HttpService.formatUri('api/Wallet'));

      return await response?.json();
    } catch (error) {
      console.error(`FAILED to load wallet from the store: '${error}'`);
    }

    // Wallet may be empty

    return [];
  }

  public static async rechargeAccount(
    code: string,
    amount: number
  ): Promise<boolean> {
    try {
      console.log(`RECHARGING wallet account: '${code}' with ${amount}`);

      const url = new URL(HttpService.formatUri('api/Wallet'));
      const params = new URLSearchParams();

      params.append('code', code);
      params.append('value', amount.toString());

      url.search = params.toString();

      await fetch(url.toString(), {
        method: 'PUT',
      });

      return true;
    } catch (error) {
      console.error(`FAILED to recharge wallet for '${code}': '${error}'`);

      return false;
    }
  }
}
