import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';
import { Account } from '../models/account';

const initialState: Account[] = [];

export const walletReducerName = 'accounts';

export function reducer(
  state = initialState,
  action: PayloadAction<Account[]>
): Account[] {
  if (action.type === 'load-accounts') {
    return action.payload;
  }

  return state;
}

storeInitialState[walletReducerName] = initialState;

storeRegistry.addReducer(walletReducerName, reducer);
