// selectors
import { Dispatch } from 'react';
import StoreState from '../../../app/store-state';
import WalletService from '../services/wallet-service';
import { walletReducerName } from './wallet-reducer';

export const selectAccounts = (state: StoreState) => state[walletReducerName];

export const selectAccount = (state: StoreState, code: string) =>
  state[walletReducerName]?.filter((account) => account.code === code)[0];

// action creators
export async function loadAccounts(dispatch: Dispatch<any>) {
  const accounts = await WalletService.loadAccounts();

  dispatch({ type: 'load-accounts', payload: accounts });
}

export async function rechargeAccount(
  code: string,
  rechargeBy: number,
  dispatch: Dispatch<any>
) {
  if (await WalletService.rechargeAccount(code, rechargeBy)) {
    await loadAccounts(dispatch);
  }
}
