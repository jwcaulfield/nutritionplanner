import React from "react";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  makeStyles,
} from "@material-ui/core";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import PropTypes from "prop-types";
import styles from "./transaction-item.module.css";
import NumberService from "../../app/services/number-service";
import DateService from "../../app/services/date-service";

const useStyles = makeStyles({
  root: {
    backgroundColor: "#eee",
    color: "black",
  },
  rootHighlighted: {
    backgroundColor: "green",
    color: "white",
  },
});

// @ts-ignore
export default function TransactionItem({ highlighted, transaction }) {
  const classes = useStyles();
  const toValue = NumberService.formatAmount(transaction.toValue);
  const toCurrency = transaction.toCode;
  const fromCurrency = transaction.fromCode;
  const submitted = DateService.formatDateTime(transaction.timestamp);

  return (
    <Accordion>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        classes={{ root: highlighted ? classes.rootHighlighted : classes.root }}
      >
        <div
          className={styles.title}
        >{`Transferred ${toValue} of ${toCurrency} from ${fromCurrency} on ${submitted}`}</div>
      </AccordionSummary>
      <AccordionDetails>
        <div className={styles.summary__panel}>
          <dl>
            <dt className={styles.summary__item__type}>From Currency:</dt>
            <dd className={styles.summary__item__value}>{fromCurrency}</dd>
            <br />
            <dt className={styles.summary__item__type}>To Currency:</dt>
            <dd className={styles.summary__item__value}>{toCurrency}</dd>
            <br />
            <dt className={styles.summary__item__type}>Amount:</dt>
            <dd className={styles.summary__item__value}>{toValue}</dd>
            <br />
            <dt className={styles.summary__item__type}>When:</dt>
            <dd className={styles.summary__item__value}>{submitted}</dd>
          </dl>
        </div>
      </AccordionDetails>
    </Accordion>
  );
}

TransactionItem.defaultProps = {
  highlighted: false,
};

TransactionItem.propTypes = {
  highlighted: PropTypes.bool,
  transaction: PropTypes.exact({
    fromCode: PropTypes.string,
    toCode: PropTypes.string,
    toValue: PropTypes.number,
    timestamp: PropTypes.instanceOf(Date),
  }).isRequired,
};
