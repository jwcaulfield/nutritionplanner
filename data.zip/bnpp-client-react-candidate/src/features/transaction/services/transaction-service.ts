import { parseISO } from 'date-fns';
import HttpService from '../../../app/services/http-service';
import { Transaction } from '../models/transaction';

export default class TransactionService {
  public static async loadTransactions(): Promise<Transaction[]> {
    try {
      console.log('LOADING trading transactions');

      const response = await fetch(HttpService.formatUri('api/Transaction'));
      const transactions = await response?.json();

      if (transactions?.length > 0) {
        return transactions
          .map(
            (item: {
              fromCode: any;
              toCode: any;
              timestamp: string;
              toValue: any;
            }) => ({
              fromCode: item.fromCode,
              toCode: item.toCode,
              timestamp: parseISO(item.timestamp),
              toValue: item.toValue,
            })
          )
          .sort(
            (a: Transaction, b: Transaction) =>
              b.timestamp.getTime() - a.timestamp.getTime()
          );
      }
    } catch (error) {
      console.error(
        `FAILED to load trading transactions from the store: '${error}'`
      );
    }

    return [];
  }
}
