export interface Transaction {
  timestamp: Date;
  fromCode: string;
  toCode: string;
  toValue: number;
}
