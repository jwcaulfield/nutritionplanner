// selectors
import { Dispatch } from 'react';
import StoreState from '../../../app/store-state';
import { transactionReducerName } from './transactions-reducer';
import TransactionService from '../services/transaction-service';

export const selectTransactions = (state: StoreState) =>
  state[transactionReducerName];

// action creators
export async function loadTransactions(dispatch: Dispatch<any>) {
  const transactions = await TransactionService.loadTransactions();

  dispatch({ type: 'load-transactions', payload: transactions });
}
