import { Observable, Subject } from 'rxjs';
import { CurrencyExchange } from '../models/currency-exchange';

export class CurrencyRateService {
  private _url = 'ws://localhost:5000';
  private _connection!: any;
  private _onChange: Subject<CurrencyExchange[]> = new Subject<
    CurrencyExchange[]
  >();

  public get onChange(): Observable<CurrencyExchange[]> {
    return this._onChange;
  }

  public async start(): Promise<boolean> {
    console.log(`STARTING Currency Rate Service: Connecting to web socket`);

    try {
      this._connection = new WebSocket(this._url);

      this._connection.onopen = () => {
        console.log('Web socket connection open');
      };

      this._connection.onmessage = (message: any) => {
        console.log('Web socket message recieved', message);
        const data: CurrencyExchange[] = JSON.parse(message.data);
        this._onChange.next(data);
      };

      return true;
    } catch (error) {
      console.error(
        `Web socket connection error. Rate data will be inaccurate: '${error}'`
      );
    }

    return false;
  }
}

const rateService = new CurrencyRateService();

export default rateService;
