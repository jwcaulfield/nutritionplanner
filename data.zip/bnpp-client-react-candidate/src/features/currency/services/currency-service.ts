import HttpService from '../../../app/services/http-service';
import { CurrencyExchange } from '../models/currency-exchange';

export default class CurrencyService {
  public static async loadCodes(): Promise<string[]> {
    try {
      console.log('LOADING currency codes');

      const response = await fetch(HttpService.formatUri('api/Currency/codes'));

      return await response?.json();
    } catch (error) {
      console.error(`FAILED to load currency codes from store: '${error}'`);
    }

    return [];
  }

  public static async loadExchanges(): Promise<CurrencyExchange[]> {
    try {
      console.log('LOADING currency exchanges');

      const response = await fetch(HttpService.formatUri('api/Currency'));

      return await response?.json();
    } catch (error) {
      console.error(`FAILED to load currency exchanges from store: '${error}'`);
    }

    return [];
  }
}
