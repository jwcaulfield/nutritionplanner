export interface CurrencyExchange {
  fromName: string;
  fromCode: string;
  fromSymbol: string;
  toName: string;
  toCode: string;
  toSymbol: string;
  value: number;
  isFavorite: boolean;
}
