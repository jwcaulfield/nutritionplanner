import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';
import { CurrencyExchange } from '../models/currency-exchange';

const initialState: Map<string, number> = new Map<string, number>();

export const currencyRatesReducerName = 'currencyRates';

export default function reducer(
  state = initialState,
  action: PayloadAction<CurrencyExchange[]>
): Map<string, number> {
  if (action.type === 'load-currency-rates') {
    const rates = new Map<string, number>();

    action.payload?.forEach((exchange) => {
      rates.set(`${exchange.fromCode}:${exchange.toCode}`, exchange.value);
    });

    return rates;
  }

  return state;
}

storeInitialState[currencyRatesReducerName] = initialState;

storeRegistry.addReducer(currencyRatesReducerName, reducer);
