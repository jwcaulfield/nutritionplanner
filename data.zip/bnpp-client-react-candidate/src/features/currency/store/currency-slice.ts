// selectors
import { Dispatch } from 'react';
import StoreState from '../../../app/store-state';
import { currencyCodeReducerName } from './currency-codes-reducer';
import CurrencyService from '../services/currency-service';
import { currencyExchangeReducerName } from './currency-exchanges-reducer';
import { currencyRatesReducerName } from './currency-rates-reducer';
import rateService from '../services/currency-rate-service';

export const selectCodes = (state: StoreState) =>
  state[currencyCodeReducerName];

export const selectExchange = (state: StoreState, from: string, to: string) =>
  state[currencyExchangeReducerName]?.filter(
    (exchange) => exchange.fromCode === from && exchange.toCode === to
  )[0];

export const selectRate = (state: StoreState, from: string, to: string) =>
  state[currencyRatesReducerName]?.get(`${from}:${to}`);

// action creators
export async function loadCodes(dispatch: Dispatch<any>) {
  const codes = await CurrencyService.loadCodes();

  dispatch({ type: 'load-currency-codes', payload: codes });
}

export async function loadExchanges(dispatch: Dispatch<any>) {
  const exchanges = await CurrencyService.loadExchanges();

  dispatch({ type: 'load-currency-exchanges', payload: exchanges });
}

export async function startExchanges(
  dispatch: Dispatch<any>
): Promise<boolean> {
  try {
    await rateService.start();

    rateService.onChange.subscribe((values) => {
      dispatch({ type: 'load-currency-rates', payload: values });
    });

    return true;
  } catch (error) {
    return false;
  }
}
