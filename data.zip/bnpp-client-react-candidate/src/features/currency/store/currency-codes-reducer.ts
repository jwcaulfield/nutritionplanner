import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';

const initialState: string[] = [];

export const currencyCodeReducerName = 'currencyCodes';

export default function reducer(
  state = initialState,
  action: PayloadAction<string[]>
): string[] {
  if (action.type === 'load-currency-codes') {
    return action.payload;
  }

  return state;
}

storeInitialState[currencyCodeReducerName] = initialState;

storeRegistry.addReducer(currencyCodeReducerName, reducer);
