import { PayloadAction } from '@reduxjs/toolkit';
import storeInitialState from '../../../app/store-initial';
import storeRegistry from '../../../app/store-registry';
import { CurrencyExchange } from '../models/currency-exchange';

const initialState: CurrencyExchange[] = [];

export const currencyExchangeReducerName = 'currencyExchanges';

export function reducer(
  state = initialState,
  action: PayloadAction<CurrencyExchange[]>
): CurrencyExchange[] {
  if (action.type === 'load-currency-exchanges') {
    return action.payload;
  }

  return state;
}

storeInitialState[currencyExchangeReducerName] = initialState;

storeRegistry.addReducer(currencyExchangeReducerName, reducer);
