import React, { useEffect } from "react";
import "./App.css";
import { Grid, Typography } from "@material-ui/core";
import { useDispatch } from "react-redux";
import Favourites from "./features/favourite/favourites";
import {
  loadCodes,
  loadExchanges,
  startExchanges,
} from "./features/currency/store/currency-slice";
import Transactions from "./features/transaction/transactions";
import Wallet from "./features/wallet/wallet";
import Transfer from "./features/transfer/transfer";

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    document.title = "Currency Dashboard - Welcome";

    loadCodes(dispatch).then();
    loadExchanges(dispatch).then();

    startExchanges(dispatch).then((started) => {
      if (!started) {
        console.warn(
          "Failed to start the currency rate service. Ticking rates will not be available."
        );
      }
    });
  }, [dispatch]);

  return (
    <div className="App">
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Typography align="left" variant="h4">
            Currency Dashboard - Welcome
          </Typography>
        </Grid>
        <Grid item xs={7}>
          <Transfer />
          <Transactions />
        </Grid>
        <Grid item xs={5}>
          <Favourites />
          <Wallet />
        </Grid>
      </Grid>
    </div>
  );
}

export default App;
