export function getExchange(fromCode, toCode, currencyData) {
    var exchange = currencyData.find(
        (x) => x.fromCode === fromCode && x.toCode === toCode
    );

    if (!exchange) {
        var invExchange = currencyData.find(
            (x) => x.fromCode === toCode && x.toCode === fromCode
        );

        if (invExchange) {
            exchange = {
                fromName: invExchange.toName,
                fromCode: invExchange.toCode,
                fromSymbol: invExchange.toSymbol,
                toName: invExchange.fromName,
                toCode: invExchange.fromCode,
                toSymbol: invExchange.fromSymbol,
                value: 1 / invExchange.value,
                isFavorite: invExchange.isFavorite,
            };
        }
    }

    return exchange;
}

export function getExchangeRate(fromCode, toCode, currencyData) {
    var exchangeRate = getExchange(fromCode, toCode, currencyData)?.value;
    return exchangeRate;
}

export function sendSuccess(res, data) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    console.log(data);
    res.end(JSON.stringify(data));
}

export function sendError(res, statusCode, data) {
    console.log(data);
    res.status(statusCode).send(data);
}
