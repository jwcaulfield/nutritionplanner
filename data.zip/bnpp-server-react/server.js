'use strict';
import { currencyData, transactions, wallet } from './data.js';
import { getExchange, getExchangeRate, sendSuccess, sendError } from './helpers.js';
import { createServer } from 'http';
import express from 'express';
import { WebSocketServer } from 'ws';
import _ from 'lodash';

var clients = new Array();

function sendCurrencyUpdate() {
    // iterate over the array of clients & send data to each
    const message = JSON.stringify(currencyData);
    for (let c in clients) {
        clients[c].send(message);
    }
}

var app = express();
app.set('port', process.env.PORT || 5000);

app.get('/Currency/codes', function (req, res) {
    var response = _.uniq([
        ...currencyData.map((x) => x.fromCode),
        ...currencyData.map((x) => x.toCode),
    ]);
    sendSuccess(res, response);
});

app.get('/Currency', function (req, res) {
    sendSuccess(res, currencyData);
});

app.get('/Currency/:code', function (req, res) {
    var fromCode = req.params.code;

    if (!fromCode) {
        sendError(res, 400, { message: 'Invalid fromCode or toCode' });
        return;
    }

    var results = currencyData.filter((x) => x.fromCode === fromCode);

    if (!results?.length) {
        sendError(res, 404, { message: `Exchange data not found for ${fromCode}.` });
        return;
    }

    sendSuccess(res, results);
});

app.get('/Currency/:fromCode/:toCode', function (req, res) {
    var fromCode = req.params.fromCode;
    var toCode = req.params.toCode;

    if (!fromCode || !toCode) {
        sendError(res, 400, { message: 'Invalid fromCode or toCode' });
        return;
    }

    var exchange = getExchange(fromCode, toCode, currencyData);

    if (!exchange) {
        sendError(res, 404, { message: `Exchange not found for ${fromCode}->${toCode}.` });
        return;
    }

    sendSuccess(res, exchange);
});

app.get('/Currency/:value/:fromCode/:toCode', function (req, res) {
    var fromCode = req.params.fromCode;
    var toCode = req.params.toCode;

    if (!fromCode || !toCode) {
        sendError(res, 400, { message: 'Invalid fromCode or toCode' });
        return;
    }

    var valueStr = req.params.value;

    if (!valueStr) {
        sendError(res, 400, { message: 'Invalid value' });
        return;
    }

    var value = Number(valueStr);

    if (!value) {
        sendError(res, 400, { message: 'Invalid value' });
        return;
    }

    var exchange = getExchange(fromCode, toCode, currencyData);

    if (!exchange) {
        sendError(res, 400, { message: `Exchange not found for ${fromCode}->${toCode}.` });
        return;
    }

    var response = { ...exchange, value: exchange.value * value };
    sendSuccess(res, response);
});

app.put('/Favorite', function (req, res) {
    var fromCode = req.query.fromCode;
    var toCode = req.query.toCode;
    var data = currencyData.find(
        (x) => x.fromCode === fromCode && x.toCode === toCode
    );

    if (!data) {
        data = currencyData.find(
            (x) => x.fromCode === toCode && x.toCode === fromCode
        );
    }

    if (!data) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Currency pair not found',
        });
        return;
    }

    if (data.isFavorite) {
        sendSuccess(res, {
            success: false,
            errorMessage: `The pair ${fromCode}->${toCode} is already favorited.`,
        });
        return;
    }

    data.isFavorite = true;
    sendCurrencyUpdate();

    sendSuccess(res, {
        success: true,
        sucessMessage: `You have added the pair ${fromCode}->${toCode} to your favorite list.`,
    });
});

app.delete('/Favorite', function (req, res) {
    var fromCode = req.query.fromCode;
    var toCode = req.query.toCode;
    var data = currencyData.find(
        (x) => x.fromCode === fromCode && x.toCode === toCode
    );

    if (!data) {
        data = currencyData.find(
            (x) => x.fromCode === toCode && x.toCode === fromCode
        );
    }

    if (!data) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Currency pair not found',
        });
        return;
    }

    if (!data.isFavorite) {
        sendSuccess(res, {
            success: false,
            errorMessage: `The pair ${fromCode}->${toCode} is already not a favorited.`,
        });
        return;
    }

    data.isFavorite = false;
    sendCurrencyUpdate();

    sendSuccess(res, {
        success: true,
        sucessMessage: `You have removed the pair ${fromCode}->${toCode} to your favorite list.`,
    });
});

app.get('/Transaction', function (req, res) {
    sendSuccess(res, transactions);
});

app.get('/Wallet', function (req, res) {
    sendSuccess(res, wallet);
});

app.put('/Wallet', function (req, res) {
    var code = req.query.code;
    var valueStr = req.query.value;

    if (!code || !valueStr) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Invalid code or value',
        });
        return;
    }

    var value = Number(valueStr);

    if (!value) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Invalid value',
        });
        return;
    }

    var data = wallet.find((x) => x.code === code);

    if (data) {
        data.value = data.value + value;
    } else {
        wallet.push({ code, value });
    }

    sendSuccess(res, {
        success: true,
        sucessMessage: `You successfully recharged ${code} with ${value}.`,
    });
});

app.post('/Trade', function (req, res) {
    var valueStr = req.query.value;
    var fromCode = req.query.fromCode;
    var toCode = req.query.toCode;

    if (!fromCode || !toCode || !valueStr) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Invalid code or value',
        });
        return;
    }

    var value = Number(valueStr);

    if (!value) {
        sendSuccess(res, {
            success: false,
            errorMessage: 'Invalid value',
        });
        return;
    }

    var fromData = wallet.find((x) => x.code === fromCode);

    if (!fromData || fromData.value < value) {
        sendSuccess(res, {
            success: false,
            errorMessage: `You don't have ${value} ${fromCode} in your wallet (currently you have ${fromData?.value ?? 0} ${fromCode}). Exchange failed.`,
        });
        return;
    }

    // Get the exchange rate
    var exchangeRate = getExchangeRate(fromCode, toCode, currencyData);

    if (!exchangeRate) {
        sendSuccess(res, {
            success: false,
            errorMessage: `Exchange rate not found for ${fromCode}->${toCode}. Exchange failed.`,
        });
        return;
    }

    var toData = wallet.find((x) => x.code === toCode);
    fromData.value = fromData.value - value;
    var toValue = value * exchangeRate;

    if (toData) {
        toData.value = toData.value + toValue;
    } else {
        wallet.push({ code, value: toValue });
    }

    transactions.push({
        timestamp: new Date().toISOString(),
        fromCode,
        fromValue: value,
        toCode,
        toValue,
    });

    sendSuccess(res, {
        success: true,
        sucessMessage: `Successfully exchanged ${value} ${fromCode} to ${toValue} ${toCode}.`,
    });
});

var server = createServer(app);
var wss = new WebSocketServer({ server });
var clients = new Array();

wss.on('connection', (thisClient, request) => {
    console.log('New web socket connection');

    clients.push(thisClient);
    thisClient.send(JSON.stringify(currencyData));

    thisClient.on('close', () => {
        var position = clients.indexOf(thisClient);
        clients.splice(position, 1);
        console.log('Web socket connection closed');
    });
});

server.listen(app.get('port'), 'localhost', function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log('Node.js API app listening at http://%s:%s', host, port);
});
