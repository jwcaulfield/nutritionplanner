# Node.js REST API

REST API for the BNP Paribas React Client to connect to.

## Build

```
npm install
```

## Run

Runs by default on port `5000`:
```
npm start
```
